package com.radiochat

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.*
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*

class Msg(val from: String, val text: String?, val file: String?, val mine: Boolean) {
    var progress by mutableStateOf(if (file != null) 0f else 1f)
    var uri by mutableStateOf<Uri?>(null)
}

object Net {
    private const val SERVICE = "com.radiochat.app"
    val msgs = mutableStateListOf<Msg>()
    val peers = mutableStateMapOf<String, String>() // endpointId -> "nome#1234"

    private lateinit var ctx: Context
    private var me = ""
    private var myId = ""
    private val pending = mutableMapOf<String, String>()
    private val incoming = mutableMapOf<Long, Payload>()
    private val names = mutableMapOf<Long, String>()
    private val rx = mutableMapOf<Long, Msg>()
    private val tx = mutableMapOf<Long, Msg>()
    private val client get() = Nearby.getConnectionsClient(ctx)

    fun start(c: Context, nick: String) {
        ctx = c.applicationContext
        me = nick
        myId = nick + "#" + (1000..9999).random()
        val s = Strategy.P2P_CLUSTER
        client.startAdvertising(myId, SERVICE, conn, AdvertisingOptions.Builder().setStrategy(s).build())
        client.startDiscovery(SERVICE, disc, DiscoveryOptions.Builder().setStrategy(s).build())
    }

    private val disc = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            // só um lado inicia a conexão, evitando colisão
            if (myId < info.endpointName) client.requestConnection(myId, id, conn)
        }
        override fun onEndpointLost(id: String) {}
    }

    private val conn = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            pending[id] = info.endpointName
            client.acceptConnection(id, pl)
        }
        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            val n = pending.remove(id)
            if (r.status.isSuccess && n != null) peers[id] = n
        }
        override fun onDisconnected(id: String) { peers.remove(id) }
    }

    private val pl = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            val from = peers[id] ?: "?"
            when (p.type) {
                Payload.Type.BYTES -> {
                    val s = String(p.asBytes() ?: return)
                    if (s.startsWith("T|")) msgs.add(Msg(from, s.substring(2), null, false))
                    else if (s.startsWith("F|")) {
                        val parts = s.substring(2).split("|", limit = 2)
                        names[parts[0].toLong()] = parts[1]
                    }
                }
                Payload.Type.FILE -> {
                    val m = Msg(from, null, names[p.id] ?: "arquivo", false)
                    rx[p.id] = m; incoming[p.id] = p; msgs.add(m)
                }
                else -> {}
            }
        }

        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {
            val m = rx[u.payloadId] ?: tx[u.payloadId] ?: return
            if (u.totalBytes > 0) m.progress = u.bytesTransferred.toFloat() / u.totalBytes
            if (u.status == PayloadTransferUpdate.Status.SUCCESS) {
                incoming.remove(u.payloadId)?.let { save(it, m) }
                m.progress = 1f
            }
        }
    }

    private fun save(p: Payload, m: Msg) {
        val src = p.asFile()?.asUri() ?: return
        val cr = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, m.file)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/RadioChat")
        }
        val dst = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return
        cr.openInputStream(src)?.use { i -> cr.openOutputStream(dst)?.use { o -> i.copyTo(o) } }
        m.uri = dst
    }

    fun sendText(t: String) {
        val ids = peers.keys.toList()
        if (ids.isEmpty()) return
        client.sendPayload(ids, Payload.fromBytes("T|$t".toByteArray()))
        msgs.add(Msg(me, t, null, true))
    }

    fun sendFile(uri: Uri, name: String) {
        val ids = peers.keys.toList()
        if (ids.isEmpty()) return
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return
        val p = Payload.fromFile(pfd)
        client.sendPayload(ids, Payload.fromBytes("F|${p.id}|$name".toByteArray()))
        client.sendPayload(ids, p)
        val m = Msg(me, null, name, true)
        tx[p.id] = m; msgs.add(m)
    }
}
