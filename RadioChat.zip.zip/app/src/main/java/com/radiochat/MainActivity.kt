package com.radiochat

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Brand = Brush.linearGradient(listOf(Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFFCB045)))
private val Grey = Color(0xFF262626)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

private fun perms(): Array<String> = buildList {
    add(Manifest.permission.ACCESS_FINE_LOCATION)
    if (Build.VERSION.SDK_INT >= 31) addAll(listOf(
        Manifest.permission.BLUETOOTH_ADVERTISE,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN))
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
}.toTypedArray()

@Composable
fun App() {
    val ctx = LocalContext.current
    var nick by remember { mutableStateOf("") }
    var started by remember { mutableStateOf(false) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) { Net.start(ctx, nick.trim()); started = true }
    }
    Box(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding().imePadding()) {
        if (started) Chat() else Login(nick, { nick = it }) { ask.launch(perms()) }
    }
}

@Composable
fun Login(nick: String, onNick: (String) -> Unit, onGo: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("RadioChat", style = TextStyle(brush = Brand, fontSize = 40.sp, fontWeight = FontWeight.Bold))
        Text("Converse sem internet, por perto", color = Color.Gray,
            modifier = Modifier.padding(top = 6.dp, bottom = 36.dp))
        Pill(nick, onNick, "Seu nome", Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brand, alpha = if (nick.isNotBlank()) 1f else 0.4f)
            .clickable(enabled = nick.isNotBlank(), onClick = onGo).padding(14.dp),
            contentAlignment = Alignment.Center) {
            Text("Entrar", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Pill(v: String, on: (String) -> Unit, hint: String, m: Modifier) {
    Box(m.clip(RoundedCornerShape(24.dp)).background(Grey).padding(horizontal = 18.dp, vertical = 12.dp)) {
        if (v.isEmpty()) Text(hint, color = Color.Gray)
        BasicTextField(v, on, Modifier.fillMaxWidth(),
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            cursorBrush = SolidColor(Color.White))
    }
}

@Composable
fun Chat() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    val state = rememberLazyListState()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        if (u != null) Net.sendFile(u, nameOf(ctx, u))
    }
    LaunchedEffect(Net.msgs.size) {
        if (Net.msgs.isNotEmpty()) state.animateScrollToItem(Net.msgs.lastIndex)
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape)
                .background(if (Net.peers.isEmpty()) Color(0xFFFFB300) else Color(0xFF2ECC71)))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("RadioChat", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (Net.peers.isEmpty()) "Procurando pessoas por perto…"
                    else Net.peers.values.joinToString { it.substringBefore('#') },
                    color = Color.Gray, fontSize = 12.sp)
            }
        }
        HorizontalDivider(color = Grey)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state,
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(Net.msgs) { Bubble(it) }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("📎", fontSize = 24.sp,
                modifier = Modifier.clip(CircleShape).clickable { pick.launch("*/*") }.padding(8.dp))
            Pill(text, { text = it }, "Mensagem…", Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(44.dp).clip(CircleShape).background(Brand).clickable {
                if (text.isNotBlank()) { Net.sendText(text.trim()); text = "" }
            }, contentAlignment = Alignment.Center) {
                Text("➤", color = Color.White, fontSize = 18.sp)
            }
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
        if (!m.mine) Text(m.from.substringBefore('#'), color = Color.Gray, fontSize = 11.sp,
            modifier = Modifier.padding(start = 8.dp, bottom = 2.dp))
        val base = Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(20.dp))
        val bg = if (m.mine) base.background(Brand) else base.background(Grey)
        Column(bg.clickable(enabled = m.uri != null) { m.uri?.let { open(ctx, it) } }
            .padding(horizontal = 14.dp, vertical = 10.dp)) {
            if (m.file != null) {
                Text("📄 ${m.file}", color = Color.White)
                if (m.progress < 1f) LinearProgressIndicator(progress = { m.progress },
                    modifier = Modifier.padding(top = 8.dp).fillMaxWidth(),
                    color = Color.White, trackColor = Color(0x55FFFFFF))
                else if (m.uri != null) Text("Toque para abrir", color = Color(0xFFCCCCCC), fontSize = 11.sp)
            } else Text(m.text ?: "", color = Color.White, fontSize = 16.sp)
        }
    }
}

private fun open(c: Context, u: Uri) {
    try {
        c.startActivity(Intent(Intent.ACTION_VIEW)
            .setDataAndType(u, c.contentResolver.getType(u) ?: "*/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

private fun nameOf(c: Context, u: Uri): String =
    c.contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    } ?: "arquivo"
